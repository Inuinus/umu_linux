#!/bin/bash

date +"%s" > datefile
