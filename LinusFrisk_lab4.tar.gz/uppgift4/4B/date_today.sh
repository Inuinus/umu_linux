#!/bin/bash

date +"%Y-%m-%d, seconds since 1970: %s"
