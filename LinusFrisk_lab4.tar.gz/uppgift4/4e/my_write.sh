#!/bin/bash

my_write(){
	echo "$1"
}

my_write "Hello world"
text="Hej hopp"
my_write "$text"
