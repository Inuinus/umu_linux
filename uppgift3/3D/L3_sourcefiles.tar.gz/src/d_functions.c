/* d_functions.c  */


#include <stdio.h>

#include "d.h"

void print_D()
{
	printf(D_MESSAGE);
}
